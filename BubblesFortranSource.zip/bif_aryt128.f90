program duzy1
!implicit real*8(a-h,o-z)

real (kind=16) :: tmax,omega,gamma,a,b,d,e,g,h,epsylon,p,p0,q1,q2,q3,q3tmp
real (kind=16) :: x,x0,x1,x2,dx,f0,f1,f2,tau,czas,deltat,fff
real (kind=16) :: xmodul,tposr,eps1,eps2


dimension seria(3)
data dx/0.001e0_16/, dodatek/0e-5_16/,  lpix/2400/,  eps1,eps2/0.001e-10_16, 0.005e-10_16/
data ip1,ip2,ip3/1,2,3/

!
!
!lpix       - liczba punktow na wykresie
!dodatek    - przytost rozwiazania do warukqow poczatkowyc q1, q2, q3
!dx         - krok rozszerzania strefy poszukiwania zera funkcji
!
!
seria=1e0_16
tmax   = 60.0e0_16     ! czas obserwacji
tposr=0.75_16*tmax
deltat = 0.5e-5_16    ! krok czasowy 10x krotszy =0.25d-5

!---------------------------dane zadania----------------
omega    = 6.6e0_16
gamma    = 1.2e0_16
a=1.76e0_16 ;!  a=1.76d0
b=0.51e0_16 ;     !b=0.51d0
d=20e0_16   ;     !d=20d0
e=27e-3_16  ;     !e=27d-3
g=26.4e-2_16;     !g=26.4d-2
!!!h=158.4d-2_16;    !158.4d-2  <-- wzorcowe (moze h=158.4d-8) !!!!!!!!!!!
epsylon=0.5e-3_16;!epsylon=0.5d-3

h=158.4e-3_16;


read (*,*)p0
!p0=11.0

!
!-----------------------koniec danych zadania-----------
q1 =1e0_16; q2 =1e0_16 - dodatek; q3 =1e0_16 - 2e0_16*dodatek  !warunki poczatkowe

lkrokow=int(tmax/deltat); lwydruk=int(float(lkrokow)/lpix)

do it=1,lkrokow
   ip1=ip1+1
   if(ip1.eq.4)ip1=1
   ip2=ip1+1
   if(ip2.eq.4)ip2=1
   ip3=ip2+1
   if(ip3.eq.4)ip3=1
   

   czas=it*deltat;   tau=omega*czas

   p=p0

   q3tmp=q3
   x1=q3-dx; x2=q3+dx;
   f1=fff(deltat,tau,x1,q1,q2,q3tmp,a,b,d,e,g,h,epsylon,gamma,omega,p)
   f2=fff(deltat,tau,x2,q1,q2,q3tmp,a,b,d,e,g,h,epsylon,gamma,omega,p)

   do while(f1*f2.gt.0e0_16) ! rozszerzanie obszaru z przecieciem zera
      i=i+1
      if(i.eq.1000)stop 'brak zbieznosci: iter1'
      x1=x1-dx; x2=x2+dx
      f1=fff(deltat,tau,x1,q1,q2,q3tmp,a,b,d,e,g,h,epsylon,gamma,omega,p)
      f2=fff(deltat,tau,x2,q1,q2,q3tmp,a,b,d,e,g,h,epsylon,gamma,omega,p)
   enddo

      i=0
100   continue
      ii=0; n=1000
   do while(x2-x1.gt.eps1.and.i.le.n)   ! szukanie zera: fff(x0)=0
      i=i+1
      if(i.eq.n)then
         go to 200
      endif

      x0=(x1+x2)/2_16
      f0=fff(deltat,tau,x0,q1,q2,q3tmp,a,b,d,e,g,h,epsylon,gamma,omega,p)
      f1=fff(deltat,tau,x1,q1,q2,q3tmp,a,b,d,e,g,h,epsylon,gamma,omega,p)
      f2=fff(deltat,tau,x2,q1,q2,q3tmp,a,b,d,e,g,h,epsylon,gamma,omega,p)
      if(f0*f1.lt.0e0_16)then
         x2=x0
      else
         x1=x0
      endif
   enddo

   if(abs(q3tmp-x0).ge.eps2)then
      x1=x0-dx;  x2=x0+dx
      al=0.5e0_16;  q3tmp=al*x0+(1e0_16-al)*q3tmp
      ii=ii+1
      if(ii.eq.1000)go to 200
      go to 100
   endif
   q3=q3tmp


   seria(ip3)=q3

   if(mod(it,lwydruk).eq.1)write(*,88)czas, q3 , p*sin(tau)
88 format(1pe12.4, 1pe14.6, 1pe12.3, 1pe12.3)

   q1=q2;  q2=q3
enddo  !koniec petli po czasie
stop
200   continue


!write(*,711)p0,seria(ip2), 0,  czas/tmax
end




!********************************************************************
real (kind=16) function fff(deltat,tau,x,q1,q2,q3tmp,a,b,d,e,g,h,epsylon,gamma,omega,p)
real (kind=16) :: aduze,bduze,q3tmp,q1,q2,a,b,d,e,g,h,deltat,epsylon,gamma,tau,x,omega,p

if(q3tmp.lt.0_16)stop 'q3<0'

aduze= &
      -3_16*a*q1/(4_16*deltat**2)&
      +a*q2/deltat**2&
      +3_16*a*q3tmp/(8_16*deltat**2)&

      +e*gamma*q2**(-3_16*gamma)*(b+d+1_16)/(2_16*deltat)&
      +h/(2_16*deltat*epsylon*(q2-epsylon))&
      -(b*e*epsylon+3e0_16*h)/(6_16*deltat*epsylon*q2)&
      +4_16*deltat*g/(8_16*deltat**2)

bduze= &
      -q2**(-3_16*gamma)*(b+d+1_16)&
      +3_16*a*q1**2/(8_16*deltat**2)&
      +a*q1*q2/deltat**2 &
      -2_16*a*q2**2/deltat**2&
      +1_16+p * sin(tau) &
!sin(tau)*(cos(tau/25.))**8& 

      -e*q1*gamma*q2**(-3*gamma)*(b+d+1e0_16)/(2*deltat)&
      +h*q1/(2e0_16*deltat*epsylon*(epsylon-q2))&
      +q1*(b*e*epsylon+3e0_16*h)/(6e0_16*q2*deltat*epsylon)&
      +d*e*q1/(2e0_16*q2**3*deltat)-g*q1/(2*deltat)&
      +b/q2 + d*(2e0_16*deltat-e*q3tmp)/(2e0_16*q2**3*deltat)

      fff = -bduze / aduze - x
end

