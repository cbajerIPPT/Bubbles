program siatka_nowa
!------------------------------------------------------------------
implicit real*8(a-h,o-z)
external d1mach, zadanie, dnrm2
integer i, imax, iopt(5), j, jmax, lwa, m, mode, n, nmax
parameter(nmax = 1, lwa = 3+(15*nmax+3*nmax*nmax)/2)

!!!splot for [i=2:21] "wyn100.dat" u (i-1):1:i w l
!!!splot for [i=1:20] "x" u 1:2*i:2*i+1 w l


!double precision d1mach, dnrm2
real*8 fjac(nmax,nmax), fnorm, fvec(nmax)
real*8 test(nmax,nmax), tol, tstmax, wa(lwa), x(nmax)

common /zad/ wpw(3,nmax),q(3,nmax),pitab(3,nmax),h,czas,ri0mem(nmax),it
common /dane/c,hpar,gduze,xmi,xro,xkappa,p0,xsigma,ri0,pac,omega
data n / nmax /, nfev/0/

!kostk, wym.= 0.03 cm, 100 kulek | (docelowo 0.1 cm)



c=0.148              !
hpar=0.118d-4        !
gduze=2d-6           ! y,yy
xmi=1d-8             !
xro=1d0     *10.         ! *100.
xkappa=1.d0          !???????????
p0=1d-6              !
xsigma=0.5d-10       !z,zz
!ri0= z danych pocz. !
pac=2d-6    *0.1         !1.2d-6      !sinus od 0.6 do 26,   czestotliwosc=1.05
omega=6.6            !
!***************************

tmax=8d0
h=5d-7
nprt=2000 !                liczba punktów na wykresie (bez względu na h i tmax)

q=0d0;  pitab=0d0;  fjac=0d0;  fvec=0d0;  x=0d0;  wa=0d0;  test=0d0


open (1,file='gener_out.dat')
do i=1,n
   read(1,*)wpw(1,i),wpw(2,i),wpw(3,i),q(3,i)
enddo
close (1)

! jednostki - przejście na centymetry
wpw=wpw/1d4
q=q/1d4        !mikrometry-->centymetry
x(:)=q(3,:)    !pozycja startowa
ri0mem=x

q(1,:)=q(3,:);  q(2,:)=q(3,:)
!     ------------------------------------------------------------------
iopt(4) = 0
!tol = dsqrt(d1mach(4))
tol=1d-12
!write(*,*)'tol=',tol



!do iii=1,10
!   write(*,170)iii,ri0mem(iii),x(iii)
!   170   format('jeden ',i5,1pe15.5,1pe15.5)
!enddo

!
! wejście: x() zawiera pierwsze przybliżenie rozwiązania,
!              na wyjściu - dokładny wynik
! tol    : dokładność na podstawie dokł. maszynowej
!
! wyjście: x() wynikowy wektor
!
!------------------------------------------------------------------
!          using dckder to check derivative computation.
!------------------------------------------------------------------
!     INFO = 0   Successful termination.  Radius of trust region has
!                been reduced to at most max(XTOL, machine precision).
!
!     INFO = 1   IMPROPER INPUT PARAMETERS.
!
!     INFO = 2   Number of calls to DNQFJ for function evaluations has
!                reached MAXFEV.
!
!     INFO = 3   XTOL is TOO SMALL. NO FURTHER IMPROVEMENT IN
!                THE APPROXIMATE SOLUTION X is POSSIBLE.
!
!     INFO = 4   Iteration is not making good progress, as
!                measured by the improvement through the last
!                five Jacobian evaluations.
!
!     INFO = 5   Iteration is not making good progress, as
!                measured by the improvement through last
!                ten function evaluations.
!

do it=1,int(tmax/h)  !pętla po czasie .................................

czas=it*h
!write(*,*)'krok=',it

x(:)=q(3,:)  !podstawienie prowizorycznego rozwiązania

m = n
call zadanie(n, x, fvec ,fjac, 2)
mode = 1

10 continue
call dckder(mode, m, n, x, fvec, fjac, nmax, test,imax, jmax, tstmax)


if(mode .eq. 2) then
   call zadanie(n, x, fvec ,fjac, 1)
   go to 10
endif

call zadanie(n, x, fvec ,fjac, 1)

!!print'(/11x,"x(j) =",5g11.3:/(17x,5g11.3))',(x(j),j=1,n)
!!print'(/1x,"  i    fvec(i)  "," ...............fjac(i,j).................."/)'
!!do i = 1,m
!!   print'(1x,i3,1x,g11.3,1x,5g11.3:/(17x,5g11.3))', i,fvec(i),(fjac(i,j),j=1,n)
!!enddo

!!print'(/1x,"test(,):"/)'

!!do i = 1,m
!!   print'(1x,i3,13x,5g11.3:/(17x,5g11.3))',i,(test(i,j),j=1,n)
!!enddo

!!print'(/1x,"imax =",i3,",    jmax =",i3,",    tstmax =",g11.3)', imax,jmax,tstmax


if(mod(it,int(tmax/h/nprt)).eq.1)write(*,71)czas,(x(ii)/ri0mem(ii),ii=1,1)  !****************************

!do iii=1,10
!   write(*,171)iii,ri0mem(iii),x(iii)
!   171   format(i5,1pe15.5,1pe15.5)
!enddo

71 format(1pe12.3,1(1pe12.4))

!------------------------------------------------------------------
!    procedura DNQSOL do rozwiązania układu równań nieliniowych
!-----------------------------------------------------------------
call dnqsol(zadanie, n, x, fvec, tol, iopt, wa, lwa)

fnorm = dnrm2(n,fvec,1)

!!print'(" termination status:  ",i6/" nfev, njev:          ",&
!!    2i6/ " final residual norm: ",g14.3/" final x():           "&
!!   /(8x,4(1pe15.6)))',  iopt(1), iopt(2), iopt(3), fnorm, (x(j), j = 1, n)

if(nfev.ne.0)write(*,*)'iopt=',nfev
if(nfev.ne.0)stop 'nfev>0'

q(3,:)=x(:)
q(1,:)=q(2,:)
q(2,:)=q(3,:)

pitab(1,:)=pitab(2,:)
pitab(2,:)=pitab(3,:)

enddo  !konec pętli po czasie

end


!==================================================================
!==================================================================
!==================================================================

subroutine zadanie(n, x, fvec ,fjac, iflag)
parameter (nmax=1)
implicit real*8(a-h,o-z)
!
! n         - liczba równań typu f(x)=0
! fvec(n)   - wektor wartości funkcji f(x)
! fjac(n,n) - macierz jacibiego
!
real*8 fvec(n), fjac(n,n), x(n)
common /zad/ wpw(3,nmax),q(3,nmax),pitab(3,nmax),h,czas,ri0mem(nmax),it
common /dane/c,hpar,gduze,xmi,xro,xkappa,p0,xsigma,ri0,pac,omega

!lista parametrów  --  tu h NIE jest krokiem czasowym


!write(*,33)((wpw(i,j),j=1,3),i=1,3)
!33 format('wpw   ',3f10.3)


!opisać pitab
!------------------------------------------------------------------

pact=0d0
!  if(czas.gt.wpw(1,i)/c)pact=pac*sin(omega*(czas-wpw(1,i)/c))
pact    =pac*      sin(omega*(czas-wpw(1,i)/c))   !?????
pactprim=pac*omega*cos(omega*(czas-wpw(1,i)/c))


if (iflag .eq. 1) then
!                                    wektor funkcji:
   do i = 1,n
!      xpi=(p0+2*xsigma/ri0mem(i))*((hpar**3-ri0mem(i)**3)/(hpar**3-q(2,i)**3))**xkappa+4*gduze &
!      *(ri0mem(i)**3-q(2,i)**3)/(3*q(2,i)**3)+2*xmi*(q(1,i)-x(i))/(h*q(2,i))-p0-pact-2*xsigma/q(2,i)

!      pitab(3,i)=xpi
!      warpidot=(pitab(3,i)-pitab(1,i))/2d0/h
!--------------------
      fvec(i)=(2d0*c*h*(hpar**3-q(2,i)**3)+(hpar**3+q(2,i)**3*(3d0*xkappa-1))* &
      (x(i)-q(1,i)))*(p0*ri0mem(i)+2*xsigma)* &
      ((hpar**3-ri0mem(i)**3)/(hpar**3-q(2,i)**3))**xkappa/(2d0*c*h*ri0mem(i) &
     *xro*(q(2,i)**3-hpar**3))+(2d0*c*h*(32*gduze*h**2*(q(2,i)**3-ri0mem(i)**3)+ &
     3d0*q(2,i)**2*(8d0*h**2*(p0*q(2,i)+pact*q(2,i)+2*xsigma)+16d0*h*xmi*(x(i) &
     -q(1,i))+q(2,i)*xro*(3*q(1,i)**2+ &
     2d0*q(1,i)*(4d0*q(2,i)-3d0*x(i))-(4d0*q(2,i)+x(i))*(4d0*q(2,i)-3d0*x(i)))))+ &
     32d0*gduze*h**2*(x(i)-q(1,i))*(q(2,i)**3+2d0*ri0mem(i)**3)+3d0*q(2,i)**3* &
     (16d0*h**3*q(2,i)*pactprim+8d0*h**2*(p0+pact)*(x(i)-q(1,i))+ &
     xro*(q(1,i)-x(i))*(q(1,i)**2+2d0*q(1,i)*(4d0*q(2,i)-x(i))-16d0*q(2,i)**2+ &
     8d0*q(2,i)*x(i)+x(i)**2)))/(48d0*c*h**3*q(2,i)**3*xro)
!   write(*,*)'wyn ',fvec(i)
      suma=0d0
      do j=1,n
         if(j.ne.i)then
            d=dsqrt( (wpw(1,i)-wpw(1,j))**2+(wpw(2,i)-wpw(2,j))**2+(wpw(3,i)-wpw(3,j))**2)
            suma=suma+q(2,j)*(q(1,j)**2+2d0*q(1,j)*(q(2,j)-x(j))-4d0*q(2,j)**2+2d0*q(2,j) &
            *x(j)+x(j)**2)/(2d0*d*h**2)
         endif
      enddo
      fvec(i)=fvec(i)+suma

   enddo

elseif (iflag .eq. 2) then
!                                    macierz jacobiego ... ... ...
   do i = 1, n
!dfi/dxi  -- tu tylko diagonala

      fjac(i,i)=(hpar**3+q(2,i)**3*(3d0*xkappa-1))*(p0*ri0mem(i)+2d0*xsigma)*((hpar**3-ri0mem(i)**3)/ &
      (hpar**3-q(2,i)**3))**xkappa/(2d0*c*h*ri0mem(i)*xro*(q(2,i)**3-hpar**3))+(12d0*c*h*q(2,i) &
     **2*(8d0*h*xmi-q(2,i)*xro*(3d0*q(1,i)-4d0*q(2,i)-3d0*x(i)))+32d0*gduze*h**2*(q(2,i)**3+2d0*ri0mem(i)** &
     3)+3d0*q(2,i)**3*(8d0*h**2*(p0+pact)-xro*(3d0*q(1,i)**2-6d0*q(1,i)*x(i)-16d0*q(2,i)**2+16d0*q(2,i)*x(i) &
     +3d0*x(i)**2)))/(48d0*c*h**3*q(2,i)**3*xro)

!write(*,*)'wyn2 ',fjac(i,i)
      do j=1,n
!         -- a tu reszta macierzy
!dfi/dxj
         if(i.ne.j)then
            d=dsqrt((wpw(1,i)-wpw(1,j))**2+(wpw(2,i)-wpw(2,j))**2+(wpw(3,i)-wpw(3,j))**2)
            fjac(i,j)= -q(2,j)*(q(1,j)-q(2,j)-x(j)) /(d*h**2)
         endif
      enddo

   enddo
endif
end
